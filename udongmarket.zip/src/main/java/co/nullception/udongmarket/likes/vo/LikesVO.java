package co.nullception.udongmarket.likes.vo;

public class LikesVO {
	
	private String boardId;
	private String nickname;

}
